<?php

// Method 1: Procedural
// $name = "Sodiq Oyedotun";
// $HNGID = "HNG-05622";
// $email = "oyedotunsodiq045@gmail.com";
// $language = "PHP";
// echo "Hello World, this is {$name} with HNGi7 ID {$HNGID} and email {$email} using {$language} for stage 2 task.";

// Method 2: Function
function helloSodiq($name, $HNGID, $email, $language) {
  echo "Hello World, this is $name with HNGi7 ID $HNGID and email $email using $language for stage 2 task.";
}

helloSodiq("Sodiq Oyedotun", "HNG-05622", "oyedotunsodiq045@gmail.com", "PHP");
?>
