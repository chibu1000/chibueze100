<?php
echo "Hello World, this is Oluwasayo Oyedepo with HNGi7 ID HNG-00026 using PHP for stage 2 task";
?>