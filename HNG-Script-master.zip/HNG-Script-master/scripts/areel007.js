const intern = {
    name: 'Sunday Morenikeji',
    id: 'HNG-01787',
    email: 'morenikejicodexiphaar@gmail.com',
    language: 'JavaScript',

    output() {
        return `Hellow World, this is ${this.name} with HNGi7 ID ${this.id}, and email ${this.email} using ${this.language} for stage 2 task`;
    }
}

console.log(intern.output());

