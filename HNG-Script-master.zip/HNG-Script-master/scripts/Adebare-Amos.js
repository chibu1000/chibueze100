const HNG = { name: 'Adebare Amos', id: 'HNG-02063', email:'adeinfo2015@gmail.com', lang:'JavaScript'};
console.log (`Hello World, this is ${HNG.name} with HNGi7 ID ${HNG.id} and email ${HNG.email} using ${HNG.lang} for stage 2 task`);
