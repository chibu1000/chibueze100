console.log("Hello world, this is Raji Mustapha with HNGi7 ID HNG-05012 and email rajimustapha30@gmail.com using javaScript for stage 2 task")
