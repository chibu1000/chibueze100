<?php
echo("Hello world, this is Sholademi Samuel with HNGi7 ID HNG-02065 and email samuelsholademi37@gmail.com using php for stage 2 task ")
  ?>

