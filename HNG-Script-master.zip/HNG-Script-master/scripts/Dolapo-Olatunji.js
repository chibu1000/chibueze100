const HNG = { 
    name: 'Dolapo Olatunji',
    id: 'HNG-01852', 
    email:'nofeesahdee@gmail.com',
    language:'JavaScript'
};
  console.log (`Hello World, this is ${HNG.name} with HNGi7 ID ${HNG.id} and email ${HNG.email} using ${HNG.language} for stage 2 task`);
