function details(value) {
  return console.log(value);
}

task = { fullName : "Oluwasegun Aiyedona", hngID: "HNG-02498", language : "JavaScript" };
details(`Hello world, this is ${task.fullName} with HNGi7 ID ${task.hngID} using ${task.language} for Stage 2 task`);