const name = "Akerele Babatunde";
const id = "HNG-04839";
const language = "Javascript";

const introduction = `Hello World, this is ${name} with HNGi7 ID ${id} using ${language} for stage 2 task`;
console.log(introduction);
