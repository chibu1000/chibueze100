//this is my commit to the stage 1 task
const info =["John Philip", "HNG-01923", "Javascript", "developerphilo@gmail.com"];

console.log(
  `Hello World, this is ${info[0]} with HNGi7 ID ${info[1]} and email ${info[3]} using ${info[2]} for stage 2 task`
);
