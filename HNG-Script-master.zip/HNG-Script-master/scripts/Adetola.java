public class Adetola {
    public static void main(String[] args) {
        System.out.println("Hello World, my name is Adetola Adeyeye with HNGi7 ID [HNG-00876] and email adetolaisaiah17@gmail.com using java for age 2 task");
    }
}




