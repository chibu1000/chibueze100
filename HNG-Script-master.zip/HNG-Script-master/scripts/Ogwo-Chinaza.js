const outputStr = 'Hello World, this is Ogwo Chinaza with HNGi7 ID HNG-02067 using JavaScript for stage 2 task';

console.log(outputStr);