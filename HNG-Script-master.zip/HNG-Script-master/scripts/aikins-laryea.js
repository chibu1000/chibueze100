const myName = "Aikins Laryea";
const myID = "HNG-05219";
const myLanguage = "Javascript";

console.log(
  `Hello World, this is ${myName} with HNGi7 ID ${myID} using ${myLanguage} for stage 2 task`
);
