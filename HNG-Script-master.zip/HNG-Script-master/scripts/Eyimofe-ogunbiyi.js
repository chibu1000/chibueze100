const fullname = "Eyimofe Ogunbiyi";
const hngId = "HNG-03694";
const language = "Javascript";
const email = "ogunbiyioladapo33@gmail.com";

const message = `Hello World, this is ${fullname} with HNGi7 ID ${hngId} and email ${email} using ${language} for stage 2 task`;
console.log(message);
