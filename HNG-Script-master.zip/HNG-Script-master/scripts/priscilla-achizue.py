details = "Hello World, this is Priscilla Achizue with HNGi7 ID HNG-00721 and email baeewele27@gmail.com using python for stage 2 task"
def myfunction ():
    print(details)

myfunction()
