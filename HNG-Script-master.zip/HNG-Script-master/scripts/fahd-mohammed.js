const HNG = { name: 'Fahd Mohammed', id: 'HNG-00561', lang:'JavaScript', email:'fahdmoh.1@gmail.com'};
console.log (`Hello World, this is ${HNG.name} with HNGi7 ID ${HNG.id} and email ${HNG.email} using ${HNG.lang} for stage 2 task`);
