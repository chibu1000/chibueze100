var myFullName = "Sangobiyi Titilayo";
var myHNGID = "HNG-04718";
var language = "JavaScript";
var email = "florencetitilayk@gmail.com";
var messageOutput = `Hello World, this is ${myFullName} with HNGi7 ID ${myHNGID} and email ${email} using ${language} for stage 2 task.`;

console.log(messageOutput)