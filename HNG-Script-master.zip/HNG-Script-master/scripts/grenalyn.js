const HNG = { name: 'Adwoa Asare', id: 'HNG-03497', language: 'JavaScript', email: 'jakazzy@gmail.com'};
console.log (`Hello World, this is ${HNG.name} with HNGi7 ID ${HNG.id} and email ${HNG.email} using ${HNG.language} for stage 2 task`);
