let name = "Adewale Samson Obidairo";
let id = "HNG-04791";
let language = "javascript";
let email = "mascot4sure@gmail.com";

let outputFile = function() {
	return console.log("Hello World, this is " + name + " with HNGi7 ID " + id+ " and email " + email + 
		" using " + language + " for stage 2 task")
};
outputFile(); 