stage2="Hello World, this is Razeb Enyi with HNGi7 ID HNG-00043 and email enyirazeb@gmail.com using Python for stage 2 task"
print(stage2)
