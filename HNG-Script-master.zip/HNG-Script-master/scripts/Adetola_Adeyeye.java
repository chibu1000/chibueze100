class Adetola_Adeyeye {
    public static void main(String[] args) {
        System.out.println("Hello World, this is Adeyeye Adetola with HNGi7 ID HNG-00876 using Java for stage 2 task");
    }
}
