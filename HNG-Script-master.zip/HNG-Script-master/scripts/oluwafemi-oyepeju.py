NAME = "Oluwafemi Oyepeju"
HNG_ID = 'HNG_00897'
LANGUAGE = "Python"
EMAIL = "oluwafemioyepeju@gmail.com"

print("Hello World, this is", NAME, "with HNGi7 ID", HNG_ID, "and email", EMAIL, "using", LANGUAGE, "for stage 2 task")
