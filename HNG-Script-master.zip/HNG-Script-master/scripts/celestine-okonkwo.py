# Task 2
name = "Okonkwo Celestine"
id = "HNG-00342"
lang = "Python"
task = "stage 2 task"
print("Hello World, this is " + name + " with HNGi7 ID " + id + " using " + lang + " for " + task)
