const fullName = "Opeyemi PETER";
const ID = "HNG-01612";
const language = "Javascript";

function intro() {
    return `Hello world, this is ${fullName } with  HNGi7 ID ${ID} using ${language } for Stage 2 task`
}

console.log(intro())
