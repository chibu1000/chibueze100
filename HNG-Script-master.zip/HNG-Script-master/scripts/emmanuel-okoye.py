""" Task for HNGi7 """
my_name = 'Emmanuel Okoye'
my_id = 'HNG-02995'
my_language = 'python'

print(f'Hello world, this is {my_name} with HNGi7 ID {my_id} using {my_language} for stage 2 task')
