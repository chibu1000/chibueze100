#Pranay-Yenagandula 

class display_text:
    def __init__(self):
        print("Hello World, this is Pranay Yenagandula with HNGi7 ID HNG-01542 and email pranay41@gmail.com using Python for stage 2 task")

d=display_text()