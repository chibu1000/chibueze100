//Mark:- Check Inputted HNG ID, Full Name & Language and return Text
const displayMessage = (hngID, fullName, language) => {
    return(console.log(`Hello World, this is ${fullName} with HNGi7 ID ${hngID} using ${language} for stage 2 task`));
};

//Mark: - Run
displayMessage("Damilola Adediran", "02794",  "Javascript");
