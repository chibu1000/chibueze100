console.log("Hello World, this is Iniubong Obonguko with HNGi7 ID HNG-03927 and email iniubongobonguko2018@gmail.com using javascript for stage 2 task");
