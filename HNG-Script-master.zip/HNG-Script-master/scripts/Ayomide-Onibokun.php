<?php
 
function hngtaskone(){
  
$firstname = "Ayomide";
$lastname = "Onibokun";
$ID = "HNG-02598";
$email = "ayo6706@gmail.com";
$lang = "PHP";

return ("Hello World, this is ".$firstname." ".$lastname." with HNGi7 ID ".$ID." and email ".$email."  using ".$lang." for stage 2 task");  
}

print hngtaskone();

?>
