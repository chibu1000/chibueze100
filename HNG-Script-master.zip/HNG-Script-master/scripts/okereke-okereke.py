#!/usr/bin/env python

#A simple python script to return a line of text which includes variables and strings for the HNG Internship Stage 2 Task

#Declaring the variables
fname = "Okereke Kalu Okereke"
id = "HNG-04125"
lang = "Python"
email = "okereke.o@live.com"

#Output text
print ("Hello World, this is " + fname + " with HNGi7 ID " + id + " and email " + email + " using " + lang + " for stage 2 task")