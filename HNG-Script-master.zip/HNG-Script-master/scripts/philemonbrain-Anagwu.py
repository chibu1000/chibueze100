#this is a program to display the following text - "Hello World, this is [full name] with HNGi7 ID [ID] using [language] for stage 2 task"

print("Hello World, this is Anagwu Brain Philemon with HNGi7 ID HNG-04096 and email philbrainy@gmail.com using Python for stage 2 task")