def intro():
	print('Hello World, this is Pranati Shete with HNGi7 ID HNG-01345 and email pranatishete23@gmail.com using python for stage 2 task')

intro()
