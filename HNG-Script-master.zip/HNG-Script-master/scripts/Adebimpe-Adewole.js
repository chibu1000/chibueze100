console.log(
  "Hello World, this is Adebimpe Adewole with HNGi7 ID HNG-02819 and email realadebimpe@gmail.com using Javascript for stage 2 task"
);
