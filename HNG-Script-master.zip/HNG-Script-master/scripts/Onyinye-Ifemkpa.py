print("Hello World, this is Onyinye Ifemkpa with HNGi7 ID HNG-02659 and email onyinyeifemkpa@gmail.com using Python for stage 2 task")
