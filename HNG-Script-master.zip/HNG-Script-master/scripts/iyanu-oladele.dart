void main() {
  final  name = 'Oladele Iyanu';
  final  id = 'HNG-02314';
  final  language = 'Dart'; 
  final  email = 'iyanuoladele123@gmail.com'; 
  /*NAME,NHNGi7 ID,PROGRAMMING LANGUAGE AND EMAIL */
  print(
  'Hello World, this is $name with HNGi7 ID $id and email $email using $language for stage 2 task'
  );
  //message output
}
