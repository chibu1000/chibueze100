(function() {
  const myName = "Olutobi Ogunsola";
  const myHNGID = "HNG-02236";
  const myEmail = "Olutobiogunsola@gmail.com";
  const language = "javaScript";

  console.log(
    `Hello World, this is ${myName} with HNGi7 ID ${myHNGID} and email ${myEmail} using ${language} for stage 2 task`
  );
})();
