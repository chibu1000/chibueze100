const HNG = { name: 'Ezeukwu Princewill', id: 'HNG-00646', lang:'JavaScript'};
console.log (`Hello World, this is ${HNG.name} with HNGi7 ID ${HNG.id} and email princewillezeukwu@gmail.com using ${HNG.lang} for stage 2 task`);
