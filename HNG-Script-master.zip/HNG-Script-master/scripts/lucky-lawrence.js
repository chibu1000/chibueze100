console.log(
  'Hello World, this is Lawrence Lucky with HNGi7 ID HNG-00524 and email lawrencelucky1999@gmail.com using JavaScript for stage 2 task'
);
