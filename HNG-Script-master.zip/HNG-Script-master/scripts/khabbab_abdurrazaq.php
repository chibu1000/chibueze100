<?php 
   
   

   $firstname = "Khabbab";
   $lastname = "Abdurrazaq";
   $id = "HNG-05015";
   $language = "PHP";

   

   $introduction = "Hello World, this is ". $firstname." ".$lastname ." with HNGi7 ID ".$id." using ".$language." for stage 2 task";
   echo $introduction;
   
?>
