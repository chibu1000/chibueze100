# Internship personal information

fullName = "Munachimso Ike"
hngi7Id = "HNG-00853"
language = "Python"


print("Hello World, this is {fullName} with HNGi7 ID {hngi7Id} using {language} for stage 2 task.")
 
