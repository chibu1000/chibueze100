def HNGi7_stage_2_task():
	my_name = "Mannan Bansal"
	my_email = "mannan_bansal@yahoo.com"
	my_HNGi7_id = "HNG-00074"
	print("Hello World, this is {0} with HNGi7 ID {1} and email {2} using python for stage 2 task".format(my_name,my_HNGi7_id,my_email))

HNGi7_stage_2_task()
