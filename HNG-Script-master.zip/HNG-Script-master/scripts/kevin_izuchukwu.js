console.log('Hello World, my name is Kevin Izuchukwu with the HNGi7 ID HNG-04697 using Javascript for stage 2 task');
