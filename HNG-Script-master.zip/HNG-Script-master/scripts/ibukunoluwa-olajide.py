# function declaration
def printOutput():
  # print string with variable values in the right position
  print ("Hello World, this is Olajide Ibukunoluwa Temitope with HNGi7 ID HNG-02393 and email ibk12mails@gmail.com using Python for stage 2 task")

# function call
printOutput()
