const HNGProfile = {
  name: 'Sifon Isaac',
  id: 'HNG-06479',
  email: 'syfonisaac@gmail.com',
  language: 'JavaScript'
};
console.log(`Hello World, this is ${HNGProfile.name} with HNGi7 ID ${HNGProfile.id} and email ${HNGProfile.email} using ${HNGProfile.language} for stage 2 task`);
