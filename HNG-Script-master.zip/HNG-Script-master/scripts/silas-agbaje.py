def app():
	print('Hello World, this is Agbaje Silas with HNGi7 ID HNG-02233 and email silasagbaje@gmail.com using python for stage 2 task')

app()
# My first time using git to code. I'm having a good time.
