var name = "Habeeb Awoyemi";
var ID = "HNG-02639";
var language = "Javascript";
var email = "awoyemi.habeeb@gmail.com";

console.log(`Hello World, this is ${name} with HNGi7 ID: ${ID} and email: ${email} using ${language} for stage 2 task`);
