<?php
print " Hello world, this is Dona Ghosh with HNGi7 ID HNG-01185 and email donaghosh3110@gmail.com using php for stage 2 task ";
