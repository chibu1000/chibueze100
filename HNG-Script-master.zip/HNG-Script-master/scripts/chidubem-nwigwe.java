public class ChidubemNwigwe {
    public static void main(String[] args) {
        System.out.println("Hello World, this is Chidubem Nwigwe with HNGi7 ID HNG-00259 and email krain9421@gmail.com using Java for stage 2 task");
    }
}