const fullName = 'Roberto Principio Jr'
const ID = 'HNG-03150'
const language = 'JavaScript'
const email = 'rdprincipio.jr@gmail.com'

console.log(`Hello World, this is ${fullName} with HNGi7 ID ${ID} and email ${email} using ${language} for stage 2 task`)