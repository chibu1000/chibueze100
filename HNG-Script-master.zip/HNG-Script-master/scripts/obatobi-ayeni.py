# HNGi7 code task for stage 2.

print("Hello world, this is Obatobi Ayeni with HNGi7 ID HNG-04196 using python for stage 2 task")
