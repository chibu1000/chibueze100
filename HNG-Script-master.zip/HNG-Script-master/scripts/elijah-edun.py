fullname = 'Elijah Edun'
hngId= 'HNG-02781'
language= 'Python'
email= 'edunelijah18@gmail.com'

def hngProfile():
    return f"Hello World, this is {fullname} with HNGi7 ID {hngId} and email is {email} using {language} for stage 2 task"
    
print(hngProfile())
