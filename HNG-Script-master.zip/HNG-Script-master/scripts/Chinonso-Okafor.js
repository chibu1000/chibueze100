console.log(
"Hello World, this is Chinonso Okafor with HNGi7 ID HNG-01408 and email justcoolk@yahoo.com using JavaScript for stage 2 task"
);