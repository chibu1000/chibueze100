<?php

$nameMe = 'Dev Quie';
$HNG7iID = 'HNG-02060';
$backendLang = 'PHP';

echo( "Hello World, this is {$nameMe} with HNGi7 ID {$HNG7iID} using {$backendLang} for stage 2 task" );
