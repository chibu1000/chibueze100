var myFullName = "Sanusi Victor";
var myHNGID = "HNG-03071";
var languageUsed = "JavaScript";
var myEmailAddress = "sanvicola2000@gmail.com"
var expectedMessage = `Hello World, this is ${myFullName} with HNGi7 ID ${myHNGID} and email ${myEmailAddress} using ${languageUsed} for stage 2 task`;

console.log(expectedMessage)