// This script returns an Hello message with my name, email, ID and preferred language
//Name
const name = `Oluwajoba Fashogbon`;
//ID
const id = `HNG-02405`;
//Email
const email = `jobafash3@gmail.com`;
//Language used
const language = `javascript`;

console.log(`Hello World, this is ${name} with HNGi7 ID ${id} and email ${email} using ${language} for stage 2 task`);
