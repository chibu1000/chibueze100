task();

function task() {
    console.log("Hello World, this is Ekor Ibor with HNGi7 ID HNG-03190 using JavaScript for stage 2 task");
}
