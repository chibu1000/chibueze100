def run_code():
    name = "Uchegbu Damianson-Wisdom Onyekachi"
    hng_id = "HNG-00644"
    language = "python"
    email = "damiansonuchegbu2017@gmail.com"

    print("Hello World, this is " + name + " with HNGi7 ID " + hng_id + " and email " + email + " using " + language + " for stage 2 task")

run_code()
