function details() {
  let me ={
    FullName: "Eboreime Rhoda",
    hngId: "HNG-01078",
    Language: "Javascript",
    email: "rhorosely@gmail.com"
  }
return `Hello World, this is ${me.FullName} with HNGi7 ID ${me.hngId} and email ${me.email} using ${me.Language} for stage 2 task`;
}
console.log(details());
