const statement = "Hello World, this is Margaret Wambui with HNGi7 ID HNG-03494 and email margarettom6@gmail.com using Javascript for stage 2 task";
console.log(statement);