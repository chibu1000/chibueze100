const fullName = "Stephen Chukwuma";
const id = "HNG-05329";
let lang = "Javascript";

console.log(`Hello World, this is ${fullName} with HNGi7 ID ${id} using ${lang} for stage 2 task.`);
