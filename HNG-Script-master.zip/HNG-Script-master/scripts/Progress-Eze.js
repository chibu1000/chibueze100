let str = ("Hello World, this is Progress Eze with HNGi7 ID HNG-00291 using javascript for stage 2 task");
console.log(str);