<?php 

    $jsonObject = [
        'file' => "semiu-biliaminu.php",
        'output' => "Hello World, this is semiu biliaminu with HNGi7 ID HNG-04209 and email codedash07@gmail.com using PHP for stage 2 task",
        'name' => "Semiu Biliaminu",
        'id' => "HNG-04209",
        'email' => "codedash07@gmail.com",
        'language' => "PHP",
        'status' => "Pass"
    ];

    echo $jsonObject['output'];// "Hello World, this is semiu biliaminu with HNGi7 ID HNG-04209 and email codedash07@gmail.com using PHP for stage 2 task"; 

?>
