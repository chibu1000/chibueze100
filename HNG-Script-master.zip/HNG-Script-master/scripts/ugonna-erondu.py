introduction = "Hello World!, this is Ugonna Erondu with HNGi7 ID HNG-00761 using Python for Stage 2 task"
print(introduction)