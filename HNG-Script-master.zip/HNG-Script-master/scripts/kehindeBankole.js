const full_name = "kehinde Bankole"

const id = "HNG-03913"

const email = "bankolek1@gmail.com"

const language = "JavaScript"

const output = `Hello World, this is ${full_name} with HNGi7 ID ${id} and email ${email} using ${language} for stage 2 task`

console.log(output)
