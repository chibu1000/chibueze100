#Stage 2 Task
#Function Definition
def akfapp():


	print('Hello World, this is Akoji Francis with HNGi7 ID HNG-01528 and email akfrendo@gmail.com using Python for Stage 2 Task')

#Function Call
akfapp()
