//Code to print statement required
var name = "Olamide Davids"; //my fullname
var id = "HNG-01138";        // my id 
var language = "Javascript";  //my chosen language
var email = "olamidedavid189@gmail.com"; //my email

    function UnsignedHype (){
        console.log("Hello World, this is" + " " +name + " "+ "with HNGi7 ID"+ " " + id +" " +"and email"+ " " + email +" "+ "using"+ " "+ language + " "+ "for stage 2 task")
    }

UnsignedHype();
