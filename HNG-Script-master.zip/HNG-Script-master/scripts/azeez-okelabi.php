<?php
 
function task(){
  
$f_Name = "Azeez";
$l_Name = "Okelabi";
$ID = "HNG-02466";
$email = "aokelabi10@gmail.com"; 
$lang = "PHP";

return ("Hello World, this is ".$f_Name." ".$l_Name." with HNGi7 ID ".$ID." and email ".$email." using ".$lang." for stage 2 task");  
}

print task();

?>
