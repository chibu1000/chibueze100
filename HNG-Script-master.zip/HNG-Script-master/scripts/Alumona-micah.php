<?PHP 

$_full_name = "Alumona Micah";
$_id = "HNC-04840";
$_lang = "php";

echo "Hello world, this is ".$_full_name." with 
HNGi7 ID ".$_id." using ".$_lang." for stage 2 task";

?>
