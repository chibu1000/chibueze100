const intro = 'Hello World, this is Umoren Samuel with HNGi7 ID HNG-04290 and email samuelumoren365@gmail.com using JavaScript for stage 2 task';

console.log(intro);