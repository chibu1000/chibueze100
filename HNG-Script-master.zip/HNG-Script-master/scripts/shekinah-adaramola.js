let fullname = 'Shekinah Adaramola';
let ID = 'HNG-03539';
let language = 'Javascript';
let email = 'shekinahadaramola@gmail.com';


console.log(`Hello World, this is ${fullname} with HNGi7 ID ${ID} and email ${email} using ${language} for stage 2 task`);
