print ("Hello World, this is Anthony Nwanze with HNGi7 ID HNG-01556 and email anthonynwanze27@gmail.com using python for stage 2 task")
