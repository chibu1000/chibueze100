<?php
$HID = 'HNG-02772';
$fullname = 'Temiloluwa Adelowo';
$email = 'moboluwaji003@gmail.com';
$language = 'PHP';

echo("Hello World, this is "
.$fullname." with HNGi7 ID "
.$HID." and email ".$email." using ".$language. " for stage 2 task");

?>
