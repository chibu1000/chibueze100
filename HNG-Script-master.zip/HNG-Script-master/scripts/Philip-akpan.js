
output = (lastName, firstName, HNGID, language) => {
  console.log(
    `Hello World, this is ${lastName} ${firstName} with HNGi7 ID HNG-${HNGID} using ${language} for stage 2 task`
  );
};

output("Philip", "Akpan", "02972", "JavaScript");
