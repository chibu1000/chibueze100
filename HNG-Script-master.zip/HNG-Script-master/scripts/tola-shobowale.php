<?php

$fullname = "Tola Shobowale";
$id = "HNG-00272";
$language = "PHP";
$email = 'shobowaletola@gmail.com';

print("Hello world,this is {$fullname} with HNGi7 ID {$id} using {$language} for stage 2 task {$email}") ;

?>