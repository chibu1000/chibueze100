function myDetails(fullName, id, language, email){
   return (`Hello World, this is ${fullName} with HNGi7 ID ${id} and email ${email} using ${language} for stage 2 task`)
}

console.log (myDetails("Augusta Ehihebolo", "HNG-02000", "JavaScript", "ehiheboloaugustar@gmail.com"))