const myName = "Egbujuo Gift";
const myID = "HNG-04683";
const myLanguage = "Javascript";
const myEmail =  "gifftchiedozie@gmail.com"

//this is my little introduction
console.log(
  `Hello World, this is ${myName} with HNGi7 ID ${myID} and ${myEmail} using ${myLanguage} for stage 2 task`
);
