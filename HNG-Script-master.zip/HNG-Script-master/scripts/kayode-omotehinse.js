
  let name = 'Kayode Omotehinse'
  let id =  'HNG-04498'
  let language = 'Javascript'

  console.log('Hello world, this is ' + name + ' ' + 'with HNG ID ' + id + ' ' + 'using ' + language + ' ' + 'for stage 2 task.')
