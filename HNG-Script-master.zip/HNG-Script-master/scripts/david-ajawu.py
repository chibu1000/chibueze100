if __name__ == '__main__':
    print('Hello World, this is {0} with HNGi7 ID {1} and email {3} using {2} for stage 2 task'\
    	  .format('David Ajawu', 'HNG-04265', 'python', 'ajawudavid@gmail.com'))
