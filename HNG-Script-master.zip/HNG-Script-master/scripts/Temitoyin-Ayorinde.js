function nameDisplay() {
  let name = "Temitoyin Ayorinde";
  let language = "JavaScript";
  let id = "HNG-02612";
  let email = "tjayorinde@gmail.com";
  const message = `Hello World, this is ${name} with HNGi7 ID ${id} and email ${email} using ${language} for stage 2 task`;
  return message;
}
console.log(nameDisplay());
