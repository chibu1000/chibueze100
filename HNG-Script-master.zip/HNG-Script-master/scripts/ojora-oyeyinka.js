const fullname = 'OJORA OYEYINKA';
const hng_id = "HNG-00431";
const language = "JavaScript";
const email = "oyeyinkaojoro@gmail.com";


const hngProfile=()=>{
    return `Hello World, this is ${fullname} with HNGi7 ID ${hng_id} and email ${email} using ${language} for stage 2 task`;
}

console.log(hngProfile());
