name = "Obasa Samuel Temitope"
_id = "HNG-04751"
language = "Python"
email = "obasasamuel96@gmail.com"
print("Hello World, this is %s with HNGi7 ID %s and email %s using %s for stage 2 task" %(name, _id, email, language))
