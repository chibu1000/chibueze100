let details={fname: "Ojewale Victor",
             hngID: "HNG-02963",
             lang: "JavaScript",
             mail: "vikingdavid41@gmail.com"};





console.log(`Hello World, this is ${details.fname} with HNGi7 ID ${details.hngID} and email ${details.mail} using ${details.lang} for stage 2 task`);
