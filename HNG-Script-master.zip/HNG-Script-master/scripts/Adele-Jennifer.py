print("Hello World, this is Adele Jennifer with HNGi7 ID HNG-01007 using Python for stage 2 task")
