def app():
	print('Hello World, this is Ademola Akinsola with HNGi7 ID HNG-01126 and email akinsolaademolatemitope@gmail.com using python for stage 2 task')

app()