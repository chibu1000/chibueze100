console.log(
  "Hello World, this is Michael Ibinola with HNGi7 ID HNG-02066 and email ibinolamichael1@gmail.com using Javascript for stage 2 task"
);
