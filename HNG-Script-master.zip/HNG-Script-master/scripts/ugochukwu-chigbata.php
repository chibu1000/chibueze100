<?php

$fullname = "Ugochukwu Chigbata";
$id = "HNG-04221";
$language = "PHP";

echo " Hello world, this is {$fullname} with HNGi7 ID {$id} using {$language} for stage 2 task";

?>