const myScript = (Name, id, language, mail) => {
  console.log(
    `Hello World, this is ${Name} with HNGi7 ID ${id} and email ${mail} using ${language} for stage 2 task`
  );
};
const Name = "Lemovou Dachi Ivan";
const id = "HNG-04042";
const language = "Javascript";
const mail = "lemovou@gmail.com";

myScript(Name, id, language, mail);
