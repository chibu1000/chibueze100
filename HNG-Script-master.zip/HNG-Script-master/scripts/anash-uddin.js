var myInfo = {
  firstName: "Anash",
  lastName: "Uddin",
  id: "00049",
  language: "Javascript",
  email: "anashuddin433@gmail.com"
};
//Output with object call
console.log('Hello World, this is ' + myInfo.firstName + ' ' + myInfo.lastName + ' with HNGi7 ID HNG-'+ myInfo.id + ' and email ' + myInfo.email + ' using ' + myInfo.language + ' for stage 2 task');
