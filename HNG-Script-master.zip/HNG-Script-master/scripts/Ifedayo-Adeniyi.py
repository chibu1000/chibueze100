"""
HNG internship Task 2
Name: Ifedayo Adeniyi
ID: HNG-02289
Track: Backend
"""

class HNG(object):

    def task1(self):
        full_name = "Ifedayo Adeniyi"
        ID = "HNG-02289"
        language = "Python"
        
        ans = "Hello World, this is Ifedayo Adeniyi with HNGi7 ID HNG-02289 and email ifedayoadeniyi@gmail.com using python for stage 2 task"
        print(ans)


IFE = HNG()
IFE.task1()
