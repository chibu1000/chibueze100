const fullName = "Ndigwe Precious";
const ID = "HNG-02193";
const lang = "JavaScript";
const email = "pndigwe23@gmail.com";

const task = `Hello world, this is ${fullName} with HNGi7 ID ${ID} using ${lang} and email ${email} for stage 2 task `;
console.log(task);
