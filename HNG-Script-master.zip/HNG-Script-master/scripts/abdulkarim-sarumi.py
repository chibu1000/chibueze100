print("Hello World, this is Abdulkarim Sarumi with HNGi7 ID HNG-03529 and email sarumi329@gmail.com using Python for stage 2 task")
