name = "Fredrick Njeri"
myId = "HNG-00655"
language = "Python"
email = "fredricknjeri64@gmail.com"

print("Hello World, this is {} with HNGi7 ID {} and email {} using {} for stage 2 task".format(name, myId, email, language))
