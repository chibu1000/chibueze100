const user = {
  firstname: 'Timilehin',
  lastname: 'Odulate',
  id: 'HNG-00395',
  lang: 'JavaScript',
  email: 'timiodulate@gmail.com',
};

let message = `Hello World, this is ${user.firstname} ${user.lastname} with HNGi7 ID ${user.id} and email ${user.email} using ${user.lang} for stage 2 task.`;

console.log(message);
