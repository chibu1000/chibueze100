let name="Victoria Salami";
let id = "HNG-03877";
let language = "Javascript";
let email = "victoriasalami18@gmail.com";
console.log(`Hello World,this is ${name} with HNGi7 ID:${id} and email ${email} using ${language} for stage 2 task.`);