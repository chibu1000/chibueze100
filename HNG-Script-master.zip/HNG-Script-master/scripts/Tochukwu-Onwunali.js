const fullName = "Onwunali Tochukwu";
const hngId = "HNG-01014";
const language = "Javascript";
const email = "onwunalitochukwu63@gmail.com"

const Message = () => {
    return `Hello World, this is ${fullName} with HNGi7 ID ${hngId} and email ${email} using ${language} for stage 2 task`
};

console.log(Message());