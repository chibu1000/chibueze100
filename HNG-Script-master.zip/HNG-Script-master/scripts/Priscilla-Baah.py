"""file: Priscilla-Baah.py
   --------------------------------
   This file prints a hello world introduction with my HNG internship details
   """
def greet():
    fullname = "Priscilla Baah"
    hng_id = "HNG-04254"
    email = "pyfbaah@gmail.com"
    language = "python"
    output = f'Hello World, this is {fullname} with HNGi7 ID {hng_id} and email {email} using {language} for stage 2 task'
    print(output)
greet()


