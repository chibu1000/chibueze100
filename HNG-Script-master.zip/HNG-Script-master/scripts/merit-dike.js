console.log('Hello World, this is Merit Dike with HNGi7 ID HNG-00392 and email dike.merit@yahoo.com using Javascript for stage 2 task');
