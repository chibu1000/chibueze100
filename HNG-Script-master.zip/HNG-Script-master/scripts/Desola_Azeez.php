<?php
$fullname ="Desola Azeez" ;
$ID = "HNG-04043";
$language = "php" ;

echo "Hello World, this is $fullname with HNGi7 ID $ID and email azeezibukunoluwa@gmail.com using $language for stage 2 task.";

?>