'''
This program prints out my name, HNG id, email and language used in the task
'''

def myScript():
	print('Hello World, this is John Shodipo with HNGi7 ID HNG-00428 and email newtonjohn043@gmail.com using Python for stage 2 task')	

myScript()
