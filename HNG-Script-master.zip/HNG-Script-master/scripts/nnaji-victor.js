//data for nnaji victor
const data = { 
  name: 'Victor Nnaji', 
  ID: 'HNG-04553', 
  language:'javaScript',
  email: "nnajivictor0@gmail.com"
  };
console.log (`Hello World, this is ${data.name} with HNGi7 ID ${data.ID} and email ${data.email} using ${data.language} for stage 2 task`);
