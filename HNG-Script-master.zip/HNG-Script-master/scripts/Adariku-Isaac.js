
// // Dart Language

// void main() {

//   //  Declearing Variable to be use for Future purpose
//   String fullName = 'Isaac Adeni Adariku';  // Fullname
//   String hNGID = 'HNG-03502';               // HNGi7 ID
//   String language = 'Dart Language';        // Programming Language 

//   //  Print the script
//   print(
//       'Hello World, this is $fullName with HNGi7 ID $hNGID using $language for stage 2 task');
// }

// ----------------------------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------------------------

// Javascript

function readMyDetailsOut(){
  
    console.log("Hello World, this is Adariku Isaac with HNGi7 ID HNG-03502 and email isaacadariku05@gmail.com using JavaScript for stage 2 task.")
}

readMyDetailsOut();
