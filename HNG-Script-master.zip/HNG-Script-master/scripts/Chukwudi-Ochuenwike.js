const user = {
    id: 'HNG-05892',
    email: 'ddmichael94@gmail.com',
    fullName: 'Chukwudi Ochuenwike',
    language: 'JavaScript'
}

console.log(`Hello World, this is ${ user.fullName } with HNGi7 ID ${ user.id } and email ${ user.email } using ${ user.language } for stage 2 task`);