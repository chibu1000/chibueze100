#task assignment to output a particular sentence indidcating name id and language used

def message(name,id,email,language):
     print("Hello world, this is {} with HNGi7 ID {} and email {} using {} for stage 2 task.".format(name,id,email,language))



message('Idris Ifeoluwa','HGN-01480','idrisloove@gmail.com','Python')
