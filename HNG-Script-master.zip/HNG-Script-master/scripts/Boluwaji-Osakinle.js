(function(){
    console.log(
        "Hello World, this is Boluwaji Osakinle with HNGi7 ID HNG-04673 and email Boluwajiosakinle@gmail.com using javascript for stage 2 task"
    );
})();