<?php

$name = 'Kenenna Onwuagba';
$id = 'HNG-02948';
$lang = 'PHP';
$email = 'onwuagbakenenna@gmail.com';

	echo ( "Hello World, this is ".$name." with HNGi7 ID ".$id." and email ".$email." using ".$lang." for stage 2 task" );

?>

