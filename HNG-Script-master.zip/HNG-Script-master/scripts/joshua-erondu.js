var name = "Joshua Erondu"
const id = "HNG-00077"
var language ="javascript"
var email = "joshuaerondu4@gmail.com"
//LOG
console.log(`Hello World, this is ${name} with HNGi7 ID ${id} and email ${email} using ${language} for Stage 2 task`)
