full_name = "Egekenze Kelechi"
ID = "HNG-02308"
language = "Python"

print("Hello World, this is {full_name} with HNGi7 ID {ID} using {language} for stage 2 task")