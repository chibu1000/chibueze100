
<?php

$fullname = "Promise Nwanozie";
$id = "HNG-03590";
$language = "PHP";
$mail = "nwanoziep@gmail.com";

print(" Hello world, this is {$fullname} with HNGi7 ID {$id} and email {$mail} using {$language} for stage 2 task ") ;

