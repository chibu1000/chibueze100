<?php 

$string1 = "Hello World, " ;
$string2 = "This is Emmanuel Aliyu with HNGi7 ID HNG-02609 using PHP for stage 2 task" ;

echo $string1 . "" . $string2 ;
?>