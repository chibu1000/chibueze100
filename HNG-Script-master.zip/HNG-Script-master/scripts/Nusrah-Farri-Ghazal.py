print("Hello World, this is Nusrah FarriGhazal with HNGi7 ID HNG-00310 using Python for stage 2 task")
