console.log("Hello World,this is Yunus Mutmainah with HNGi7 ID HNG-02696 using javascript for stage 2 task")
