const details = {
	name: "Wisdom Ojiakor",
	id: "HNG-01979",
	language: "JavaScript",
	email: "wojiakor@gmail.com"
};

console.log(`Hello world, this is ${details.name} with HNGi7 ID ${details.id} and email ${details.email} using ${details.language} for stage 2 task`);
