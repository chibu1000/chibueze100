function MoveToStage2(name, id, email, language) {
  console.log(
    'Hello World, this is ' + name + ' with HNGi7 ID ' + id + ' and email ' + email + ' using ' + language + ' for stage 2 task'
  );
}

MoveToStage2(
  "Efereyan Karen Simisola",
  "HNG-01050",
  "kimsyefe@gmail.com",
  "Javascript"
);
