const lanreScript=(value)=>{
    console.log(`Hello World, this is ${value.name} with HNGi7 ID ${value.id} and email ${value.email} using ${value.language} for stage 2 task`)
}

const value={
    name:"Olayiwola Olanrewaju",
    id:"HNG-02315",
    email:"larry_coal@outlook.com",
    language:"Javascript"
};

lanreScript(value)