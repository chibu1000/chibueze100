
echo "Hello World, this is Sylvanus Jerome with HNGi7 ID HNG-02780 and email sylvanusjerome@gmail.com
using PHP for stage 2 task";
