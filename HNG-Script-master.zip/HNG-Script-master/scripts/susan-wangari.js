// a javascript code
console.log('Hello world, my name is Susan Wangari with HNGi7 ID 02129 and email address susanwangari810@gmail.com using javascript for stage 2 project');
