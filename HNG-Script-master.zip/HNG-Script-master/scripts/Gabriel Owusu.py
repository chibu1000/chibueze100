fullname="Gabriel Owusu"
ID="HNG-00774"
language="Python"

print("Hello World, this is "+fullname+" with HNGi7 ID -" +ID+ " using "+language+" for stage 2 task")
