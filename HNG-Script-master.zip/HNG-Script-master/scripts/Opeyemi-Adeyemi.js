


(function (name="Adeyemi Opeyemi David",id="HNG-03135",language="Javascript") {
    console.log('Hello World, this is ' + name + ' with HNGi7 ID ' + id + ' using language ' + language + ' for stage 2 task' )

 })()
