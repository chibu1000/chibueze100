let slack_full_name = "Oladokun Joshua"
let HNG_id = "HNG-03210"
let Language_used = 'Javascript'
let email = 'oladokunjoshua2016@gmail.com'

let output_statement = ((name, id, lang, email) => {
  return console.log(`Hello World, this is ${name} with HNGi7 ID ${id} and email ${email} using ${lang} for stage 2 task`
  )
})

output_statement(slack_full_name, HNG_id, Language_used, email)
