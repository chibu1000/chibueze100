<?php

$first_name = "Ridwan";
$last_name = "Gbadamosi";
$hng_id = "HNG-04960";
$email = "ridwangbadamosi@gmail.com";
$language = "PHP";

echo "Hello World, this is " .$first_name." " .$last_name. " with HNGi7 ID " .$hng_id. " and email " .$email. " using " .$language. " for stage 2 task.";


?>
