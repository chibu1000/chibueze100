var fullname = "Emmanuel Erasmus Sulai";
var HNGi7_ID = "HNG-01104";
var email = "'2016wealthtips@gmail.com'";
var LanguageUsed = "Javascript";
var myMessage = "Hello world, this is " + fullname + " with HNGi7 ID " + HNGi7_ID + " and email " + email + " using " + LanguageUsed + " for stage 2 task.";
console.log(myMessage);