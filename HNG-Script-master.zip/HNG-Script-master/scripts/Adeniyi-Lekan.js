const myScript = (fullname, id, language, email) => {
  console.log(`Hello World, this is ${fullname} with HNGi7 ID ${id} and email ${email} using ${language} for stage 2 task`);
}
const fullname='Adeniyi Lekan Femi';
const ID ='HNG-02968';
const language='JavaScript';
const email ='holarfemilekan049@gmail.com'
myScript(fullname, ID, language, email);