<?php

$nm = "Nelson Chinedu";
$lg = "PHP" ;
$em = "nelsonnedum@gmail.com";
$HNG_id = "HNG-03542";

echo "Hello World, this is ".$nm." with HNGi7 ID ".$HNG_id." and email ".$em." using ".$lg." for stage 2 task" ;






?>
