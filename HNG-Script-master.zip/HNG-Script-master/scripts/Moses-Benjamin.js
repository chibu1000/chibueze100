const name = "Sunday Moses Benjamin";
const id = "HNG-00680";
const language = "javascript";
let email = "sundaybenjamin08@gmail.com"

const result = ()=>{
	return console.log(`Hello World, this is ${name} with HNGi7 ID ${id} and email ${email} using ${language} for stage 2 task`)
};
result(); 