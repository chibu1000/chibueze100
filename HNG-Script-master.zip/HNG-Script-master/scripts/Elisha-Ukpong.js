
function echoMyName(){
    console.log("Hello World, this is Elisha Ukpong with HNGi7 ID HNG-03659 and email ishukpong418@gmail.com using JavaScript for stage 2 task.")
}

echoMyName();