let user = {
    name: "Kevin Izuchukwu",
    id: "HNG-04697", 
    language: "Javascript"
}

console.log(`Hello World, this is ${user.name} with the HNGi7 ID ${user.id} using ${user.language} for stage 2 task`);



