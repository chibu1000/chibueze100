
<?php

$myname = "Joshua Paul";
$myid = "HNG-05491";
$mylanguage = "PHP";

print(" Hello world, this is {$myname} with HNGi7 ID {$myid} using {$mylanguage} for stage 2 task ") ;

