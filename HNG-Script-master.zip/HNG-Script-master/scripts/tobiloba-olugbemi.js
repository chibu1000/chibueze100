const name = 'Tobiloba Olugbemi';
const id = 'HNG-03473';
const lang = 'JavaScript';
const email = 'tobilobaolugbemi@gmail.com'

console.log(`Hello world, this is ${name} with HNGi7 ID ${id} and email ${email} using ${lang} for stage 2 task`);