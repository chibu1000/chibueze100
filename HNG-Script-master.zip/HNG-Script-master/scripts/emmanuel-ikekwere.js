// HNGi7 Internship Stage 2 task:

let myCode = "Hello World, this is Emmanuel Ikekwere with HNGi7 ID HNG-00209 and email: emmaikekwere@gmail.com using Javascript for stage 2 task";

console.log(myCode);
