const myName = 'Joshua Ogbonna'
const hngId = 'HNG-03663'
const language = 'JavaScript'

console.log(`Hello World, this is ${myName} with HNGi7 ID ${hngId} using ${language} for stage 2 task`)