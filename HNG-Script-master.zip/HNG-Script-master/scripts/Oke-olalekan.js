
const myData = {
	fullname: "Oke Olalekan",
	ID: "HNG-01322",
	language: "Javascript",
	email: "speakingatoms@gmail.com" 
}


console.log(`Hello World, this is ${myData.fullname} with HNGi7 ID ${myData.ID} and email ${myData.email} using ${myData.language} for stage 2 task`) 