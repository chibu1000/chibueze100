<?php

$message = "Hello World, this is John Olatubosun with HNGi7 ID HNG-01444 using PHP for stage 2 task.";

echo $message;

?>