var name = "Yusuf Kehinde Hussein";
var id = "HNG-02156";
var language = "JavaScript";
var email = "yusufkehinde11@gmail.com"

console.log(
  `Hello World, this is ${name} with HNGi7 ID ${id} and email ${email} using ${language} for stage 2 task"`
);
