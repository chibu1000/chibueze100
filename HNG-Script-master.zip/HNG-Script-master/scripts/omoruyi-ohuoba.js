let fullName = "Omoruyi Ohuoba";
let hngId = "HNG-03458";
let email = "davidngozi2000@yahoo.com";
let language = "javaScript";

let output = () => {
    console.log(" Hello World, this is " + fullName + " with HNGi7 ID " + hngId + " and email " + email + " using " + language + " for stage 2 task " );

}

output();