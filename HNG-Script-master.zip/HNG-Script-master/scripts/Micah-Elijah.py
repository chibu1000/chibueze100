#!/usr/bin/python3
def main():
    def printDetails():
        name = "Micah Elijah"
        hng_id = "HNG-04316"
        language = "Python"
        email = "melijah200@gmail.com"
        text = ("Hello World, this is {} with HNGi7 ID {} and email {} using {} for stage 2 task").format(name, hng_id,email, language)
        print(text)

    printDetails()
if __name__ == "__main__":
    main()



