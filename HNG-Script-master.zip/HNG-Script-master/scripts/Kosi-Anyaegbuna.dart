void main() {
  String name = 'Kosi Anyaegbuna';
  String id = 'HNG-02471';
  String email = 'kosilevan@yahoo.co.uk';
  String languageUsed = 'Dart';

  String returnStatement() {
    return 'Hello World, this is $name with HNGi7 ID $id and email $email using $languageUsed for stage 2 task';
  }

  print(returnStatement());
}
