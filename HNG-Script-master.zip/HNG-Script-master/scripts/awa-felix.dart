
// Main Function - Dart Language
void main() {
  final String name = 'Awa Felix'; //name
  final String hngID = 'HNG-00187'; //HNG ID
  final String email = 'felixhope30@gmail.com';             //email
  final String lang = 'Dart';        // Language 

  //  Print the task
  print(
      'Hello World, this is $name with HNGi7 ID $hngID and email $email using $lang for stage 2 task');

}

