const fullName = "Bolaji Ola";
const language = "JavaScript";
const ID = "HNG-1703";
const email = "afeezbolajiola@gmail.com";

function intro(){
  return `Hello World this is ${fullName} with HNGi7 ID ${ID} and email ${email} using ${language} for stage 2 task`

}
console.log(intro())
