
stage2 = { 
	fullName : "Mutiat Akinwale", 
	hngID: "HNG-01406", 
	language : "Javascript" ,
	email : "mutiatakinwale@gmail.com"
	};
	
	var output = `Hello world, this is ${stage2.fullName} with HNGi7 ID ${stage2.hngID} and email ${stage2.email} using ${stage2.language} for Stage 2 task`;
	
	console.log(output);


