<?php

$name = 'Yezid Olanase';
$id = 'HNG-01607';
$email = 'olanaseyezid@gmail.com';
$language = 'PHP';

echo "Hello World, this is {$name} with HNGi7 ID {$id} and email {$email } using {$language} for stage 2 task.";

?>