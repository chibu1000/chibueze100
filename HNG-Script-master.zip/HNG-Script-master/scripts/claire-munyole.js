

function task_two_helloworld(name, identification, email, scripting_language) {
  console.log(
    `Hello World, this is ${name} with HNGi7 ID ${identification} and email ${email} using ${scripting_language} for stage 2 task`
  );
}
task_two_helloworld("Claire Munyole", "HNG-00045", "munyolec@gmail.com", "Javascript");



