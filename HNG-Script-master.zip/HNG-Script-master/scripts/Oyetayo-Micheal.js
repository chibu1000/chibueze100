var name = "Oyetayo Micheal";
var ID = "HNG-03767";
var language = "Javascript";

console.log(`Hello World, this is ${name} with HNGi7 ID ${ID} using ${language} for stage 2 task`);
