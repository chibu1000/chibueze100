const Name = "Efuetbeja Bright";
const ID = "HNG-00907";
var Language = "JavaScript"
let email = "tanzebright@gmail.com"

 console.log("Hello World, this is " + Name + " with HNGi7 ID " + ID  + " and email " +  email +  " using " + Language + " for stage 2 task");