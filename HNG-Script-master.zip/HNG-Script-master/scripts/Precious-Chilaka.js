const fullName = "Precious Chilaka";
const hngId = "HNG-07770";
const email = "email preshchilaka06@gmail.com";
const language = "JavaScript";

const message  =  `Hello World, this is ${fullName} with HNGi7 ID ${hngId} and ${email} using ${language} for stage 2 task.`;

console.log(message);