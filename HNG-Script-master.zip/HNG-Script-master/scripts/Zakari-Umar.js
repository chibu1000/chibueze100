const task = "Hello world, this is Umar Muhammad Zakari with HNGi7 ID HNG-01897 and email umarfarouqft@gmail.com using Javascript for stage 2 task"
console.log(task)
