def hngi_stage_1():
    print("Hello World, this is Favour Anefu with HNGi7 ID HNG-01504 and email favouranefu@gmail.com using Python for stage 2 task")

if __name__ == '__main__':
    hngi_stage_1()
