let name = ('Adeyemi Oluwatimileyin')
let email = ('oluwatimilehin14@gmail.com')
let language = ('JavaScript')

console.log('Hello World, this is ' + name + ' with HNGi7 ID HNG-02238 and email ' + email + ' using ' + language + ' for stage 2 task')
//console.log() displays the text in quotes as an output
//This is my way of making my code special.

