(function () {
  console.log(
    "Hello World, this is Promise Johnson with HNGi7 ID HNG-03039 using JavaScript for stage 2 task."
  );
})();
