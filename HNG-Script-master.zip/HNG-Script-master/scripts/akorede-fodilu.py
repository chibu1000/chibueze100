# print out my details
full_name = "Akorede Fodilu"
my_id = "HNG-04279"
language = "Python"

print("Hello World, this is {0} with HNGi7 ID {1} using {2} for stage 2 task".format(full_name, my_id, language))