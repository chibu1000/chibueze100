#HNGi7

if __name__ == '__main__':
    print("Hello World, this is Emmanuel Olowu with HNGi7 ID HNG-03010 and email olowurobin@gmail.com using Python for stage 2 task")