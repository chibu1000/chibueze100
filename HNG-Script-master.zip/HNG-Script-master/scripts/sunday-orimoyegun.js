﻿console.log(
    'Hello World, this is Orimoyegun Sunday with HNGi7 ID HNG-01400 and email orimoyegun.sunday@gmail.com using Javascript for stage 2 task'
);