print("Hello World, this is James Dayo with HNGi7 ID HNG-05786 and email jdayo2012@gmail.com using Python for stage 2 task")
