console.log('Hello World, this is Samuel Fatodu with HNGi7 ID HNG-03538 and email samuelfatodu@gmail.com using JavaScript for stage 2 task.');
