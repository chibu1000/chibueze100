function individualTask() {
	const full_name = 'Akinsola Boluwatife';
	const ID = 'HNG-01814';
	const language = 'Javascript';
	const email = 'boluwatifeakinsolas@gmail.com';
    console.log(`Hello World, this is ${full_name} with HNGi7 ID ${ID} and email ${email} using ${language} for stage 2 task`);
}
individualTask() 
