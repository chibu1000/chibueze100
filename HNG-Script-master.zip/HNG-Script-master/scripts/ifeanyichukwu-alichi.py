print("Hello World, this is Alichi Ifeanyichukwu with HNGi7 ID HNG-01341 and email alichiifeanyi@yahoo.com using Python for stage 2 task")
