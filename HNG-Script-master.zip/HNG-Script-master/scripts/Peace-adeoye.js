const myName= {name: 'Peace Adeoye',
               id: 'HNG-06335',
               language: 'Javascript',
  email: 'adebolapeace0@gmail.com'
};

const myOutput = `Hello World, this is ${myName.name} with HNGi7 ID ${myName.id} and email ${myName.email} using ${myName.language} for stage 2 task`;

console.log(myOutput);
