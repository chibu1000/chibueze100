function Details(){
console.log("Hello World, this is Caleb Ali with HNGi7 ID HNG-01156 and email caleb_ali@yahoo.co.uk using JavaScript for stage 2 task");
}
Details();
