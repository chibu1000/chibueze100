const fullName = "Ali Abdulsamad Tolulope";
const id = "HNG-02955";
const language = "JavaScript";
const email = "iphenom01@gmail.com";

result = `Hello World, this is ${fullName} with HNGi7 ID ${id} and email ${email} using ${language} for stage 2 task`;
console.log(result);
