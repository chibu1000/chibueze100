// An object of my data
const inputData = {
    name: "Emmanuel Ezenwigbo",
    id : "HNG-00517",
    language: "JavaScript",
    email: "emmanuelezenwigbo@gmail.com"
}

// Output object in desired format
let outputData = `Hello World, this is ${inputData.name} with HNGi7 ID ${inputData.id} and email ${inputData.email} using ${inputData.language} for stage 2 task`;

// Log format to the console
console.log(outputData);
