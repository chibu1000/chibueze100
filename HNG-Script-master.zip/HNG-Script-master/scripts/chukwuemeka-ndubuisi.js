let firstName = "chukwuemeka";
let lastName = "ndubuisi";
let myHNGi7ID = "HNG-01433";
let languageUsed = "javascript";
let email = "ndubuisichukwuemeka2@gmail.com";
console.log("Hello World,this is  " + firstName + " " +  lastName + " with HNGi7 ID  " + myHNGi7ID + " and email "+ email + "  using  " + languageUsed + "  for stage 2 task  ");
