const HNG = { name: 'Damilola Martin', id: 'HNG-05598', lang:'JavaScript'};
console.log (`Hello World, this is ${HNG.name} with HNGi7 ID ${HNG.id} using ${HNG.lang} for stage 2 task`);
