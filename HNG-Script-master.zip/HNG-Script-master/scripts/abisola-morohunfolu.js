const fullName = 'Abisola Morohunfolu';
const id = 'HNG-01645';
const language = 'javascript';

console.log(
	`Hello World, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task`
);
