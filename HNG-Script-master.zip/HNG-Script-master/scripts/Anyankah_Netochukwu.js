const profile =["Anyankah Netochukwu", "HNG-05168", "Javascript", "nanyankah@gmail.com"];

console.log(
  `Hello World, this is ${profile[0]} with HNGi7 ID ${profile[1]} and email ${profile[3]} using ${profile[2]} for stage 2 task`
);