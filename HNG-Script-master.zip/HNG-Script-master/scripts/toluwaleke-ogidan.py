
print("Hello world, this is ogidan toluwaleke with HNGi7 ID HNG-03053 and email toluwalekeogidan@gmail.com using python for stage 2 task ")


