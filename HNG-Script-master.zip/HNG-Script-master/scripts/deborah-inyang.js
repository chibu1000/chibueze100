var fullName = ("Deborah Inyang");
var id = ("HNG-01672")
var language = ("Javascript");
var email = ('deborahfinyang@gmail.com')

console.log ('Hello World, this is' + fullName + 'with HNGi7 ID' + id + 'and email' + email + 'using' + language + 'for stage 2 task.');

