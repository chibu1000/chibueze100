const fullName = 'Oluwole Dada';
const hngId = 'HNG-03623';
const email = 'dadaoluwafemitaiwo@gmail.com';
const language = 'JavaScript';

console.log(`Hello World, this is ${fullName} with HNGi7 ID ${hngId} and email ${email} using ${language} for stage 2 task`);