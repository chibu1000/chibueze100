print("Hello World, this is Adedayo Adewole with HNGi7 ID HNG-02957 using python for stage 2 task")
