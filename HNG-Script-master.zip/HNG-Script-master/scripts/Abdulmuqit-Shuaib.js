console.log(
    "Hello World, this is Abdulmuqit Shuaib with HNGi7 ID HNG-02508 and email horleryeeworler@gmail.com using Javascript for stage 2 task"
);