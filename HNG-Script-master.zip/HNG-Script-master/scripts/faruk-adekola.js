
const firstName = "Faruk";
const lastName = "Adekola";
const fullName = firstName + " " + lastName;
const myHNGID = "HNG-01835";

function farukDetails() {
const sentence= "Hello World, this is " + fullName + " with HNGi7 ID " + myHNGID + " and email adekoladamilola4@gmail.com using JavaScript for stage 2 task";
console.log(sentence);
}

farukDetails();
