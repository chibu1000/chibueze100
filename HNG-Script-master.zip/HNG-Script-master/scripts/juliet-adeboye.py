
def bio():
	print('Hello World, this is Juliet Adeboye with HNGi7 ID HNG-00159 and email julietadeboye01@gmail.com using Python for stage 2 task')	

myScript()
