<?php

$first_name = "Adeleye";
$last_name = "Ladejobi";
$hng_id = "HNG-02958";
$email ="emmy007.el@gmail.com";

echo "Hello World, this is ".$first_name." ".$last_name." with HNGi7 ID ".$hng_id." and email ".$email." using php for stage 2 task";

?>

