full_name="Hussaini Muhammad Auwal"
id="HNG-01895"
language="Python"
print("Hello World, this is {0} with HNGi7 ID {1} using {2} for stage 2 task".format(full_name,id,language))
	
