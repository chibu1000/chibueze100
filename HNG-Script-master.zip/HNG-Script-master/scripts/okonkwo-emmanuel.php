<?php

$name = 'Okonkwo Emmanuel';
$hngId = 'HNG-00082';
$language = 'php';

echo("Hello World, this is $name with HNGi7 ID $hngId using $language for stage 2 task");

?>
