

//console.log("Hello World, this is Adelakun Oluwatobiloa with HNGi7 ID HNG-04753 using JavaScript for Stage 2 task");


// Hello World, this is [full name] with HNGi7 ID [ID] using [language] for stage 2 task

const fullname = "Adelakun Oluwatobiloba";
const id = "HNG-04753";
const language = "JavaScript";
const email = "adelakuntobiloba1@gmail.com";

console.log(`Hello World, this is ${fullname} with HNGi7 ID ${id} and email ${email} using ${language} for stage 2 task`);
