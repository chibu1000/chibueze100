const user = {
  name: "Victor shigaba",
  internshipId: "HNG-02863",
  language: "Javasript",
  email:"victorshigaba300@gmail.com"
};
const response = `Hello World, this is ${user.name} with  HNGi7 ID ${user.internshipId} and using email ${user.email} using ${user.language} for stage 2 task`;
console.log(response);
