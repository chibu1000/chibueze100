name = "Chima Ugbo"
ID = "HNG-01119"
language = "Python"
email = "chimaugbo@gmail.com"
print("Hello World, this is " + name + " with HNGi7 ID " + ID + " and email " + email + " using " + language + " for stage 2 task")
