console.log("Hello World, this is Mariam Ismael Saka with HNGi7 ID HNG-01795 using javascript for stage 2 task")
