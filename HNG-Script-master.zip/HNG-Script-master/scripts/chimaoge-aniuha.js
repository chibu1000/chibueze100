function printStatement(){
    let firstName = 'Chimaoge';
    let lastName = 'Aniuha';
    let IdentificationNumber = 'HNG-02075'
    let email = 'chimaaniuha@gmail.com';
    let lang = 'Javascript'
    let Statement = `Hello World, This is ${firstName} ${lastName} with HNGi7 ID ${IdentificationNumber} and email ${email} using ${lang} for stage 2 task.`;
    console.log(Statement);
}

printStatement();