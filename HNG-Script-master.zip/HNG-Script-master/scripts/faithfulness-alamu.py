outformat = "Hello World, this is %s with HNGi7 ID %s and email %s using %s for stage 2 task\n"
name = "Faithfulness Alamu"
hngid = "HNG-02407"
email = "vaguemail369@gmail.com"
language = "python"


if __name__ == '__main__':
	print(outformat % (name, hngid, email, language))
