def print_myinfo():
    print('Hello world, this is Emem Lawrence Etukudo',
    'with HNG ID HNG-02217 and',
    'email saspiee@gmail.com using python for',
    'stage 2 task')


print_myinfo()