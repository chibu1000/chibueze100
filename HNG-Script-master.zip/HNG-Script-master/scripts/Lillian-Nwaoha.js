var file = "Hello World, this is Lillian Nwaoha with HNGi7 ID HNG-01291 and email lillian.nwaoha@yahoo.com using Javascript for stage 2 task"

console.log (file) ;
