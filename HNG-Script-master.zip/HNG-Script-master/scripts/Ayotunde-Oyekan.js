var name = "Ayotunde Oyekan";
var ID = "HNG-00437";
var language = "JavaScript";
var email = "oyekanayotunde56@gmail.com";
var result = `Hello World, this is ${name} with HNGi7 ID ${ID} and email ${email} using ${language} for stage 2 task`;

console.log(result);
