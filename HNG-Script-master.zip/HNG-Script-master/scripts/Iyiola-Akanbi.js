const Name = "Iyiola Akanbi";

const ID = "HNG-00391";

const Language = "Javascript";

const Email = "iyiola.dev@gmail.com";

const task = () => {

    return `Hello world, this is ${Name} with HNGi7 ID ${ID} and email ${Email} using ${Language} for stage 2 task`

};

console.log(task());
