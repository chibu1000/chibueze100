const STATUS = {
    "firstName": "Daniel",
    "lastName": "Adeneye",
    "language": "Javascript",
    "id": "HNG-02304",
    "email" : "adeneyedaniel007@gmail.com"
};

const RESULT = () => `Hello World, this is ${STATUS.firstName} ${STATUS.lastName} with HNGi7 ID ${STATUS.id} and email ${STATUS.email} using ${STATUS.language} for stage 2 task`;
console.log(RESULT());
