let  outPut = ()=> {
    let profile ={
      fullName: "Gabriel Raji",
      Id: "HNG-00100",
      email: "rajigabrielebunoluwa@gmail.com",
      Language: "Javascript/nodejs express",
      status: "Pass"
    }
  return `Hello World, this is ${profile.fullName} with HNGi7 ID ${profile.Id} using ${profile.Language} for stage 2 task`;
  }
  console.log(outPut());
