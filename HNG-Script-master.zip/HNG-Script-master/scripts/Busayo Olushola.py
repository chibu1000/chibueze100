print ("Hello World, this is Busayo Olushola with HNGi7 ID HNG-02411 using python for stage 2 task")
