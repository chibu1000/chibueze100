package com.example.java;

public class Nsikak_Akpan {

        public static void main(String[] args) {
        System.out.println("Hello World, my name is Nsikak Akpan, with HNGi7 ID  HNG-01250 and email tonyalex6258@gmail.com and i would be using java for my stage 2 task");
            }


        }






