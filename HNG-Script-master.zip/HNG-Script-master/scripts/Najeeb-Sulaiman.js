console.log("Hello World, this is Najeeb Sulaiman with HNGi7 ID HNG-05740 using Javascript for stage 2 task")
