<?php 

  $fullname = "Nnamdi Aninye";
  $hng_id = "HNG-04740";
  $email = "unix1gl@gmail.com";
  $lang = "JavaScript";

echo "Hello World, this is " .  
  $fullname . " with HNGi7 ID " . 
  $hng_id . " and email " . 
  $email . " using " . 
  $lang . " for stage 2 task";