function hng(name, id, language, email){
    console.log(`Hello World, this is ${name} with HNGi7 ID ${id} and email ${email} using ${language} for stage 2 task`)
}

hng("Quadri Abdulmalik", "HNG-00837", "JavaScript", "mackquadrizz@gmail.com" )