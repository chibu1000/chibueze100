#Name: Aaron Kipkoech
#Task: Stage 2 HNG Task

name = "Aaron Kipkoech"
id = "HNG-03499"
language = "python"
email = "aaronrono42@gmail.com"

print("Hello World, this is " + name + " with HNGi7 ID " + id + " and email " + email + " using " + language + " for stage 2 task")
//this is a first attempt
//i hope i dont mess this up
//tried as much as possible to follow the steps
//so help me
