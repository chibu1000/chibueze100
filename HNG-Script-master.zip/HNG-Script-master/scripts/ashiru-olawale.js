const person = {
  fullName: 'Ashiru Olawale',
  id: 'HNG-01958',
  language: 'JavaScript',
  email: 'walebant1@gmail.com',
};

const speech = `Hello World, this is ${person.fullName} with HNGi7 ID ${person.id} and email ${person.email} using ${person.language} for stage 2 task`;

console.log(speech);
