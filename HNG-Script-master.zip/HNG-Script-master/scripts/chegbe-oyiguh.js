const name = 'Oyiguh Ojochegbe';
let id = 'HNG-03796';
let language = 'javascript'

console.log(`Hello World,this is ${name} with HNGi7 ID:${id} using ${language} for stage 2 task.`);
