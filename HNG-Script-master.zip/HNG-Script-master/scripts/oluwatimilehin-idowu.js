// This file represents my submission for task 2
console.log("Hello World, this is Oluwatimilehin Idowu with HNGi7 ID HNG-05074 and email oluwatimilehin.id@gmail.com using Javascript for stage 2 task.");

