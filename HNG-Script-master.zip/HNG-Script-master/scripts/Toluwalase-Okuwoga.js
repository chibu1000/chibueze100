const fullName = 'Toluwalase Okuwoga';
const hngId = 'HNG-01109';
const language = 'JavaScript';

console.log(`Hello World, this is ${fullName} with HNGi7 ID ${hngId} using ${language} for stage 2 task`);
