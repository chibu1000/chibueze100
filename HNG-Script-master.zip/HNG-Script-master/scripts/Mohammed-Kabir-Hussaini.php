<?php 

print "Hello world, this is Mohammed Kabir Hussaini with HNGi7 ID HNG-00759 and email iamquintissential@gmail.com using php for stage 2 task"

?>
