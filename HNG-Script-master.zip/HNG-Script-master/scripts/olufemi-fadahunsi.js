let fullName = "Olufemi Fadahunsi";
let id = "HNG-00269";
let language = "JavaScript";
let email = "olufemifad@gmail.com"

console.log("Hello World, this is " + fullName + " with HNGi7 ID " + id +  " and email " + email + " using " + language + 
" for stage 2 task.");