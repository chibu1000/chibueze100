def sayHello(myName,myId,myLanguage, myEmail):
    print("Hello World, this is {name} with HNGi7 ID {id} and email {email} using {language} for stage 2 task"
    .format(name = myName, id = myId, language = myLanguage, email = myEmail))
    return

sayHello("Tjahe Essomba Jules Renaud","HNG-01452","python","julesrenaud10@gmail.com")
