# stage 2 task


name = "Marline Khavele"
id = "HNG-04957"
email = "khavelemarline@gmail.com"
language = "python"


result = "Hello World, this is " + name + " with HNGi7 ID " + id + " and email " + email + " using " + language + " for stage 2 task"

print (result)

# print(
#     f"Hello World, This is { name } with HNGi7 ID {id} and {email} using { language} for stage 2 task"
# )

