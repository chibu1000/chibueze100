const printMessage = (fullName, id, email, language) => {
    var message = `Hello World, this is ${fullName} with HNGi7 ID ${id} and email ${email} using ${language} for stage 2 task`
    console.log(message)
}

printMessage('Lois Adegbohungbe', 'HNG-04138', 'loisadegbohungbe@gmail.com', 'Javascript')