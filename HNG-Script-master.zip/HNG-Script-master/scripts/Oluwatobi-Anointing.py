Anointing_Message = 'Hello World, this is Oluwatobi Anointing with HNGi7 ID HNG-02004 and email adeyokunnuo@gmail.com using Python for stage 2 task'


print(Anointing_Message)
