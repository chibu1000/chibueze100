const details = {
  name: "Emmanuel Ikwuoma",
  hngID: "HNG-04940",
  lang: "JavaScript",
};

console.log(
  `Hello World, this is ${details.name} with HNGi7 ID ${details.hngID} using ${details.lang} for stack 2 task`
);
