let diamond = 'Hello World, this is Olushola Ajayi with HNGi7 ID HNG-03064 and email speak2emmans@gmail.com using JavaScript for stage 2 task '
console.log(diamond)
