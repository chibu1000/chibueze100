var name = " Marcus Elendu ";
var id = " HNG-00390 ";
var language = "Javascript";
var myemail = "jomarc233@gmail.com";

console.log(
  "Hello World, this is" +
    name +
    "with HNGi7 ID" +
    id +
    "and email " +
    myemail +
    " using " +
    language +
    " for stage 2 task"
);
