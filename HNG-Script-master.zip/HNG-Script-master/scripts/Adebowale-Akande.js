let person = {
  name: "Adebowale Akande",
  id: "HNG-01754",
  language: "Javascript",
  email: "akandeadebowale0@gmail.com",
};

console.log(
  `Hello World, this is ${person.name} with HNGi7 ID ${person.id} and email ${person.email} using ${person.language} for stage 2 task`
);
