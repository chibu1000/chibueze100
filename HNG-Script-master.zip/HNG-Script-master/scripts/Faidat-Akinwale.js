task = { fullName : "Faidat Akinwale", hngID: "HNG-04059", language : "JavaScript" };

var details = `Hello world, this is ${task.fullName} with HNGi7 ID ${task.hngID} and email faidatakinwale@gmail.com using ${task.language} for Stage 2 task`;

console.log(details);
