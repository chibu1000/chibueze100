def introduction():

  txt = "Hello World, this is {} with HNGi7 ID {} and email {} using {} for stage 2 task"

  full_name = "Nerona Sook"
  hng_id = "HNG-00194"
  email = "neronasook@gmail.com"
  language = "Python"

  print(txt.format(full_name, hng_id, email, language))

introduction()