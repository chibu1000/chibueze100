<?php
$Name ="Pesova Osueke" ;
$lang = "php" ;
$id = "HNG-02105";


echo "Hello World, this is $Name with HNGi7 ID $id and email Pesova13@gmail.com using $lang for stage 2 task.";

?>