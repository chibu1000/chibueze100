const FullName = "Henry Mutegeki";
const HngId = "HNG-01577";
const Language = "Javascript";
const Email = "henrymutegeki117@gmail.com"

message = `Hello World, this is ${FullName} with HNGi7 ID ${HngId} and email ${Email} using ${Language} for stage 2 task`;

console.log(message);
