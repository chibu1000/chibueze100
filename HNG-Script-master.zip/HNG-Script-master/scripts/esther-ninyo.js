
console.log('Hello world, this is Esther Ninyo with HNGi7 ID HNG-04176 and email ninyhorlah6@gmail.com using Javascript for stage 2 task');