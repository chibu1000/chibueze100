def task_2():
  return "Hello World, this is Steven Kolawole with HNGi7 ID HNG-01749 and email kolawolesteven99@gmail.com using python for stage 2 task."
  
print(task_2())
