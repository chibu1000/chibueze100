const myData = {
  name : 'Olamide Aboyeji',
  HNG_ID : 'HNG-05560',
  language : 'Javascript',
  stage : 2,
  email : 'aboyejiolamide15@gmail.com'
};

const { name, HNG_ID, language, stage, email } = myData;
console.log(`Hello World, This is ${name} with HNGi7 ID ${HNG_ID} and email ${email} using ${language} for stage ${stage} task`);
