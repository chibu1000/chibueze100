#python 3.7.1

print ("Hello world, this is Divakaran With HNGi7 ID HNG-01546 and email dhvakr@gmail.com using python for stage 2 task")
