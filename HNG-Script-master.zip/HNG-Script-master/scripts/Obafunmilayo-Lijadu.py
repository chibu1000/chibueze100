def run():
    my_name = 'Obafunmilayo Samuel Lijadu'
    my_id = 'HNG-02821'
    my_email = 'lijsamobafunmilayo@gmail.com'
    my_stack = 'python'
    print("Hello World, this is",my_name,"with HNGi7 ID",my_id,
    "and email",my_email,"using",my_stack,"for stage 2 task")

run()