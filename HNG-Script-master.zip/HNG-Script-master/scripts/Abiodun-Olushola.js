const firstName = "Abiodun";
const lastName = "Olushola";
const userName = "Eshjay";
const fullName = `${firstName} ${lastName}`;
const id = "HNG-03204";
const language = "JavaScript";
const message = `Hello World, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task`;

console.log(message);
