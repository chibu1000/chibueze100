<?php

/* 
 i will be using a function to execute 
 the stage 1 task 

 */
//Declaring the function messageTask
 function messageTask($fullName, $id, $language, $validEmail){
  echo "Hello World, this is $fullName with HNGi7 ID $id and email $validEmail using $language for stage 2 task" ;

  //echoing the text

  //Hello World, this is Elisha Simeon Ukpong Udoh with HNGi7 ID HNG-01827 and email simeon.udoh45@gmail.com using python for stage 2 task

 }
 //calling back the function

 messageTask("Agboola Sola", "HNG-04047", "PHP", "agboolasola6@gmail.com");
?>
