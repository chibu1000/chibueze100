full_name="Kirezi Cyisa Fidele"
id="HNG-03961"
language="Python"
email="fihacker000@gmail.com"
def print_function():
    print("Hello World, this is " + full_name + " with HNGi7 ID " + id + " and email " + email + " using " + language + " for stage 2 task")


print_function()