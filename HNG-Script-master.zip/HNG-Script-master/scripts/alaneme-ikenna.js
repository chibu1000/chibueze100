// Setting my variables
const name = 'Alaneme Ikenna';
const id = 'HNG-00763';
const language = 'javaScript';

const info = `Hello World, this is ${name} with HNGi7 ID ${id} using ${language} for stage 2 task`;

console.log(info);