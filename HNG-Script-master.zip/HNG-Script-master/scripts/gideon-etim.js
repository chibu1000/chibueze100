let fullName = "Gideon Etim";
let hngId = "HNG-00144";
let email = "gidiblack@gmail.com";
let language = "Javascript";

let message = "Hello World, this is " + fullName + " with HNGi7 ID " + hngId + " and email " + email + " using " + language + " for stage 2 task";
console.log(message);