
let name = "Damilola Oseni";
let myId = 'HNG-00746';
let language = 'Javascript';
let email = 'mlola.oseni@gmail.com'

function myFunction (){
    return `Hello World, this is ${name} with HNGi7 ID ${myId} and email ${email} using ${language} for stage 2 task`
}

console.log(myFunction());

