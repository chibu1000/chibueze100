const fullName = 'Uchechukwu Nwafor';

const id = 'HNG-03041';

const email = 'nwaforuchechukwu2007@gmail.com';

const language = 'Javascript';

(function (fullName, id, email, language) {
    console.log(`Hello World, this is ${fullName} with HNGi7 ID ${id} and email ${email} using ${language} for stage 2 task`);
}(fullName, id, email, language));
