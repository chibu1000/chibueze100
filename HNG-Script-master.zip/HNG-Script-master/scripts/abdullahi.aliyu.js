{
	let me = {
    firstName: "Abdullahi",
    lastName: "Aliyu",
	HNGID: 	01827,
	email: "abdoulfurya@gmail.com"
}
console.log("Hello World, this is  " + me.firstName +  " "+ me.lastName + " with HNGi7 ID HNG-"+ me.HNGID + " and email: " + me.email + " using javascript for stage 2 task.")
}