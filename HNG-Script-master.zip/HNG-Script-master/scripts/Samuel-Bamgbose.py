
fullname = "Samuel Bamgbose"
ID = "HNG-00339"
dev_language = "Python"

def main():
    print("Hello World, this is", fullname,"with HNGi7 ID",ID,"using",dev_language,"for stage 2 task")

main()
