full_name = "Anita Achu"
id = "HNG-04285"
language = "python"
email = "anitatom20@gmail.com"

print("Hello World, this is " + full_name + " with HNGi7 ID " + id + " and email " + email + " using " + language + " for stage 2 task")
