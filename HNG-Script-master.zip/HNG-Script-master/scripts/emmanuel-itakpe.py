# HNG stage 2 task, here is my script.
#By: Emmanuel Itakpe

print("Hello world, this is Emmanuel Itakpe with HNGi7 ID HNG-01311 and email itakpeemma@gmail.com using Python for stage 2 task")
