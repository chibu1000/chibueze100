console.log("Hello World, this is Victor Nonso Okeke with HNGi7 ID HNG-03505 using javaScript for stage 2 task");
