var str = "Hello World, this is Anjolaoluwa Onifade with HNGi7 ID HNG-02003 and email anjyfade@gmail.com using Javascript for stage 2 task.";
console.log(str);
