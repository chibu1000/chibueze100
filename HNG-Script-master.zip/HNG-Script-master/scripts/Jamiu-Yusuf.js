console.log("Hello World, this is Jamiu Yusuf with HNGi7 ID HNG-02240 and email boladeboss@gmail.com using Javascript for stage 2 task")
