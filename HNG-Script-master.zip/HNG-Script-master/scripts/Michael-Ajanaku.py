print("Hello world, this is Michael Ajanaku with HNGi7 ID HNG-02854 and email remiljw@gmail.com  using Python for stage task 2.")
