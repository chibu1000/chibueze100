<?php

$name = "Paul Oismoje";
$HNGID = "HNG-01966";
$language = "php";

print "Hello World, this is $name with HNGi7 ID $HNGID using $language for stage 2 task.";

?>