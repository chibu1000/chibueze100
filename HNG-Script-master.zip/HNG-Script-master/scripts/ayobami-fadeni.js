developer = {
    name : 'Ayobami Fadeni',
    id : 'HNG-00940',
    language : 'JavaScript',
    email: 'fadeniayobami@gmail.com'
}

const output = `Hello world, this is ${developer.name} with HNGi7 ID ${developer.id} and email ${developer.email} using ${developer.language} for stage 2 task`;

console.log(output);
