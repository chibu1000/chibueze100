const output = () => {
    const data = {
        name: 'Areh Babatunde',
        id: 'HNG-01568',
        language: 'Javascript',
        email: 'arehtunde96@gmail.com'
    }
    return `Hello World, this is ${data.name} with HNGi7 ID ${data.id} and email ${data.email} using ${data.language} for stage 2 task.`;
}

console.log(output());
