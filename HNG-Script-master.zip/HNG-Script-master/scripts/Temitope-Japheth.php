<?php

// This is my stage 2 task

$name = "Temitope Japheth";

$id = "HNG-04757";

$language = "PHP";

$email = "japhethtemitope@gmail.com";

print(" Hello world, this is {$name} with HNGi7 ID {$id} and email {$email} using {$language} for stage 2 task ") ;


