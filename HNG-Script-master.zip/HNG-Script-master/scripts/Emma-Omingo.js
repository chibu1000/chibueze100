const HNG = { name: 'Emma Omingo', id: 'HNG-01412', language:'JavaScript'};
console.log (`Hello World, this is ${HNG.name} with HNGi7 ID ${HNG.id} using ${HNG.language} for stage 2 task`);
//This is in Javascript language
