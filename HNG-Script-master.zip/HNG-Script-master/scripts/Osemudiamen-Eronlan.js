function printMessage() {
  console.log(
    "Hello World, this is Osemudiamen Eronlan with HNGi7 ID HNG-03059 and email oseeronlan@gmail.com using JavaScript for stage 2 task"
  );
}

printMessage();
