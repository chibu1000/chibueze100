const name = "Olamide Agboola";
const id = "HNG-00261";
const email = "saintlammy@gmail.com"
const language = "Javascript";

const display = `Hello World, this is ${name} with HNGi7 ID ${id} and email ${email} using ${language} for stage 2 task`;

console.log(display);