developer = {
    name : 'Caleb Effiong',
    id : 'HNG-00951',
    language : 'JavaScript'
}

const output = `Hello world, this is ${developer.name} with HNGi7 ID ${developer.id} using ${developer.language} for stage 2 task`;

console.log(output);
