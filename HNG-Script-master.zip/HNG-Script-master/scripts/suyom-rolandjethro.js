const fullName = 'Roland Jethro Suyom',
      id = 'HNG-01426',
      email = 'rolandjethrosuyom@yahoo.com',
      language = 'JavaScript';

const details = `Hello World, this is ${fullName} with HNGi7 ID ${id} and email ${email} using ${language} for stage 2 task`;

console.log(details)