console.log(
  'Hello World, this is Salifu Sani Rich with HNGi7 ID HNG-00246 and email sarscodes@gmail.com using JavaScript for stage 2 task'
);
