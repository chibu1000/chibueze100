Name = "Douglas Dominic"
ID = "HNG-01669"
Language = "Python"
Email = "ejise45@gmail.com"
print("Hello World, this is",Name, "with HNGi7 ID", ID,"using",Language,"for stage 2 task", "you can reach me via email with ",Email)
