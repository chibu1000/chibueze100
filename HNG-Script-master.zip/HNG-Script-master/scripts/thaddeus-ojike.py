# My submission for HNGi7 task
# Code will output required string.

# creating needed variables
fullName = 'Thaddeus Ojike'
ID = 'HNG-04124'
language = 'Python'
email = 'thaddeusojike@gmail.com'

# creating required string
result = f'Hello World, this is {fullName} with HNGi7 ID {ID} and email {email} using {language} for stage 2 task'

# outputting string
print(result)
