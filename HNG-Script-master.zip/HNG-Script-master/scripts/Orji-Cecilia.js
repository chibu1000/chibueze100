
//task 2 to stage 2 promotion using javascript

const myResult = "Hello World, this is Orji Cecilia with HNGi7 ID HNG-02009 using Javascript for stage 2 task";

console.log(myResult);
