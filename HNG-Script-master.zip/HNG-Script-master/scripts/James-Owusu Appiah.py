my_FirstName = "James"
my_SurnameName = "Owusu-Appiah"
my_HNGId = "HNG-03682"
my_Language = "python"
my_EmailAddress = "jamesoappiah2003@gmail.com"
    
print("Hello World, this is "+ my_FirstName + " " + my_SurnameName + " with HNGi7 ID " + my_HNGId + " and email " + my_EmailAddress + " using " + my_Language + " for stage 2 task")

