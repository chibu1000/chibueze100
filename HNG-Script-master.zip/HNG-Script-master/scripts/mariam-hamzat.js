var fullname = "Mariam Hamzat";
var id =  "HNG-02768";
var language = "JavaScript";
var email = "titilayobolamide247@gmail.com"
console.log("Hello World, this is " + fullname + " with HNGi7 ID " + id + " and email " + email + " using " + language + " stage 2 task ");