const fullName = 'Timfon Ekott';
const id = 'HNG-04227';
const userName = 'Bloodhound';
const language = 'JavaScript';
const email = 'edmund.timfon@gmail.com';

const message = (() =>
  `Hello World, this is ${fullName} with HNGi7 ID ${id} and email ${email} using ${language} for stage 2 task.`)();

console.log(message);
