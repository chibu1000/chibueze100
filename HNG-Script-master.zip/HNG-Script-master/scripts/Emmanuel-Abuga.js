const Name = "Abuga Emmanuel";
const ID = "HNG-03993";
const Lang = "Javascript"

const result = () => {
    return `Hello world, this is ${Name} with HNGi7 ID ${ID} using ${Lang} for stage 2 task`
};

console.log(result());