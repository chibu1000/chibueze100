<?php
$hello1 = "Hello World, this is JemimaNaomi Godwin Ben with HNGi7 ID";
$hello2 = "HNG-02526 and email benjemimanaomi@gmail.com using php for stage 2 task";
echo $hello1 . " " . $hello2;
?>