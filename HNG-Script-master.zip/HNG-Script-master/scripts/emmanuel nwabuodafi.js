const HNG = { name: 'Emmanuel Nwabuodafi', id: 'HNG-01295', lang:'JavaScript'};
console.log (`Hello World, this is ${HNG.name} with HNGi7 ID ${HNG.id} and email Nwabuodafiemmanuel@gmail.com using ${HNG.lang} for stage 2 task`);
