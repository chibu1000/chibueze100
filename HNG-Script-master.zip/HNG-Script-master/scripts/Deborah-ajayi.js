var name= 'Deborah Ajayi'
username= 'speak2debby'
id= 'HNG-03850'
email='speak2debby@gmail.com'
console.log(`Hello World, this is ${name} with HNGi7 ID ${id} and email ${email} using Javascript for Stage 2 task`)
