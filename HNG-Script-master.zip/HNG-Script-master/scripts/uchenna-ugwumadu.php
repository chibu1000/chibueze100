<?php

echo( "Hello World, this is Uchenna Ugwumadu with HNGi7 ID HNG-02970 and email josebright29@gmail.com using PHP for stage 2 task." );
