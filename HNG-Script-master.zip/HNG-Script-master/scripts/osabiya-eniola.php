<?php

	$message = "Hello World, this is Eniola Osabiya with HNGi7 ID HNG-00143 and email eosabiya@gmail.com using PHP for stage 2 task";

	echo $message;
?>