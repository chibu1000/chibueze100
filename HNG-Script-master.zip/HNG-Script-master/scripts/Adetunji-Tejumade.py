def Hello():
    print("Hello world, this is Adetunji Tejumade With HNGi7 ID HNG-00420 and email tejumadeadetunji@gmail.com using python for stage 2 task")

Hello()