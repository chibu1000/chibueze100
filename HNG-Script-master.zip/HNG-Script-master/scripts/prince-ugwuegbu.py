a= {'First-Name':'Prince', 'Last-Name':'Ugwuegbu','HNGI7-ID':'HNG-00430','Language':'Python'}

print("HELLO WORLD","this is",a['First-Name'],a['Last-Name'], "with HNGi7 ID",a['HNGI7-ID'],"using language",a['Language'])
