const info = ["Joseph Obochi","HNG-05688","javascript"]

console.log("Hello world this is "+info[0]+" with hngi id "+ info[1]+" using "+info[2])