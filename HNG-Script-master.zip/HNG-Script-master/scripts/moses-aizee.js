console.log(
  "Hello World, this is Moses Aizee with HNGi7 ID HNG-03671 and email azmotech@outlook.com using Javascript for stage 2 task."
);
