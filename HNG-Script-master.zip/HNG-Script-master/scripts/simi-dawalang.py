full_name = "Simi Morayo Da-Walang"
hng_ID = "HNG-04578" 

"""The ID is a string because a zero is
the first digit. As an integer, it would
have been omitted in the output."""

email = "simidawalang@gmail.com"
language = "Python"

print("Hello World, this is " + full_name + " with HNGi7 ID " + hng_ID + " and email " + email + " using " + language + " for stage 2 task.")
