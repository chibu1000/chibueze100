var myfirstName = "Prosper";
var mylastName = "Ekwerike";
var myhngID = "HNG-05129";
var mylanguage = "Javascript";
var myemail = "pekwerike@gmail.com"

let outputResult = `Hello World, this is ${myfirstName} ${mylastName} with HNGi7 ID ${myhngID} and email ${myemail} using ${mylanguage} for stage 2 task`;

console.log(outputResult);
