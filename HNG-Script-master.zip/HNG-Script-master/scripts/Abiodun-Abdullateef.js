(function () {
  const full_name = 'Abiodun Abdullateef';
  const ID = 'HNG-00908';
  const language = 'JavaScript';
  const email = 'yomlateef@yahoo.com';

  console.log(
    `Hello World, this is ${full_name} with HNGi7 ID ${ID} and email ${email} using ${language} for stage 2 task`
  );
})();
