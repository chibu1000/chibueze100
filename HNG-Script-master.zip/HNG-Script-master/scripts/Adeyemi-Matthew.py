"""
STAGE 2

A script that returns my fullname, HNGi7 ID using python Language.

"""

while True:
    Full_Name= "Adeyemi Matthew Iyanuoluwa"
    HNGi7_ID= "HNG-03087"
    Language= "Python"
    Email= "mattadeyemi15r@gmail.com"
    print("Hello World, this is",Full_Name, "with HNGi7 ID", HNGi7_ID,"and email",Email, "using",Language, "for stage 2 task.")

    break
