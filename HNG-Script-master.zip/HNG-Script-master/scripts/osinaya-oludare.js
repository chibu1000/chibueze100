const bio = "Hello World, this is Osinaya Oludare with HNGi7 ID HNG-04443 using Javascript for stage 2 task";
console.log(bio);