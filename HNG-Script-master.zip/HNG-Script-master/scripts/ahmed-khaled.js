console.log(`Hello World, this is Ahmed Khaled with HNGi7 ID HNG-02924 using javascript for stage 2 task`);
