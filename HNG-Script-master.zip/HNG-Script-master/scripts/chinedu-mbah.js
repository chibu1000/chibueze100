//Text outputted using console.log

let fullname = "Chinedu Mbah"; //fullname

const ID = "HNG-01190"; //internship ID

let language = "javaScript"; //preffered language for task

console.log(
    `Hello World, this is ${fullname} with HNGi7 ID ${ID} using ${language} for stage 2 task`
);
