# HNG stage 2 task
# name=Airenovboise Israel
# ID=HNG-05846
# language="python"


def HNG_Task():
    print(
        "Hello World, this is Israel Airenovboise with HNGi7 ID HNG-05846 and email airenov500@gmail.com using python for stage 2 task"
    )


HNG_Task()
