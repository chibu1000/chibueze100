<?php

  $fullname="Ufoegbulam Chukwuemeka Kingsley";
  $hng_board_id="HNG-05670";
  $language_used="PHP";
  $email="kingsleyemeka31@gmail.com";
  
  echo "Hello World, this is ".$fullname." with HNGi7 ID ".$hng_board_id."and email ".$email." using ".$language_used." for stage 2 task.";

?>