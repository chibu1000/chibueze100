const myData = {
	fullname: "David ENORAGBON",
	ID: "HNG-04977",
	language: "Javascript",
	email: "enoragbondavid35@gmail.com" 
}


console.log(`Hello World, this is ${myData.fullname} with HNGi7 ID ${myData.ID} and email ${myData.email} using ${myData.language} for stage 2 task`)
