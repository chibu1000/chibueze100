const username = {
  name: "Oladayo Babalola",
  id: "HNG-00626",
  language: "JavaScript",
  email: "oladayobb@gmail.com"
};
const literal = `Hello World, this is ${username.name} with HNGi7 ID ${username.id} and email ${username.email} using ${username.language} for stage 2 task`;
console.log(literal);
