// Setting my variables
const name = 'Oliver Otchere';
const id = 'HNG-01090';
const language = 'javaScript';
const email='oliverotchere4@gmail.com';

const info = `Hello World, this is ${name} with HNGi7 ID ${id} and email ${email} using ${language} for stage 2 task`;

console.log(info);
