#HNGi7 Task 2

name = "Audu Ozioiza Queen"
ID = "HNG-05210"
dev_language = "Python"

print("Hello World, this is {name} with HNGi7 ID {ID} using {dev_language} for stage 2 task")
