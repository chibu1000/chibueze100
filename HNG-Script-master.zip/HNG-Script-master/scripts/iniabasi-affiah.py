'''Module to print out fullname, id and language'''

FULLNAME = "Affiah Ini-Abasi Bernard"
ID = "HNG-00758"
LANGUAGE = "Python"
EMAIL = "iniabasi.bernard@gmail.com"

print("Hello World, this is " + FULLNAME + " with HNGi7 ID "
      + ID + " and email " + EMAIL + " using " + LANGUAGE
      + " for stage 2 task")
