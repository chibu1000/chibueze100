
<?php
echo "Hello World, this is Bariesuador Harmony Nwibani with HNGi7 ID HNG-00046 and email esuador@gmail.com using PHP for Stage 2 task";
?>
