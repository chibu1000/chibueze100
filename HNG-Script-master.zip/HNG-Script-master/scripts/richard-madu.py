print("Hello World this is Richard Madu with HNGi7 ID HNG-01777 using python for stage 2 task")
