<?php
$name = "Erondu Emmanuel";
$id   = "HNG-06303";
$mail ="erone007@gmail.com";
$lang ="PHP";
echo "Hello World, this is $name with HNGi7 ID $id and email $mail using $lang for Stage 2 task";
?>