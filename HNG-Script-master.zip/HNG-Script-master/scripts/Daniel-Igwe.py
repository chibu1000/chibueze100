name = "Daniel Igwe"
HNG_id = "HNG-02682"
E_MAIL = "danielchibuzoigwe@gmail.com"

def generate_output():
    return "Hello World, this is {} with HNGi7 ID {} and email {} using Python for stage 2 task".format(name, HNG_id, E_MAIL)
    
if __name__ == "__main__":
    print(generate_output())
