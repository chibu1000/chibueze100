let fullname = "Chidubem Onyeukwu";
let id = "HNG-03733";
let language = "Javascript";

function message() {
 const message = "Hello World, this is" + fullname +" with HNGi7 ID" + id + "using" + language + " for stage 2 task ";
 
 return message;

}
console.log(message());
