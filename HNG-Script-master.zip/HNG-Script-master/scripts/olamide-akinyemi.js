const sayHi = () => {
    const greet = 'Hello World, this is olamide akinyemi with HNGi7 ID HNG-01639 my e-mail is olamideakinyemi41@gmail.com, using javascript for stage 2 task';
    return greet;
} 
console.log(sayHi());