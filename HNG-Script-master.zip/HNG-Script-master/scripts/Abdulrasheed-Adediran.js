    var myFirstName = "Abdulrasheed";
    var myLastName = "Adediran";
    var myId = "HNG-02383";
    var myLanguage = "JavaScript";
    var myEmail = "adediran.ajibade@gmail.com"; 
    
    myScript = "Hello World, this is " +  myFirstName + " " + myLastName + " with HNGi7 ID " + myId + " and email " + myEmail + " using " + myLanguage + " for stage 2 task.";

    console.log(myScript);
