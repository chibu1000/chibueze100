name = "Raiyan Mukhtar"
id = "HNG-01816"
email= "raiyan.dev6@gmail.com"
language ="python"

print("Hello world, this is {0} with HNGi7 ID {1} and email {2} using {3} for stage 2 task.".format(name,id,email,language))
