// Hello World, this is [full name] with HNGi7 ID [ID] using [language] for stage 2 task

const fullname = "Alexander Ugwuanyi";
const id = "HNG-02522";
const language = "JavaScript";
const email = "ugwuanyi.alexander.chukwuebuka@gmail.com";

console.log(`Hello World, this is ${fullname} with HNGi7 ID ${id} using ${language} for stage 2 task`);