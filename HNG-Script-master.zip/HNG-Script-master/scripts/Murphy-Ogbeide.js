console.log("Hello World, this is Murphy Ogbeide with HNGi7 ID-01770 and email ogbeidemurphy@gmail.com using JavaScript for stage 2 task.");
