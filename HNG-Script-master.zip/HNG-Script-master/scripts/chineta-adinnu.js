//object
let output = {
  name: "Chineta Adinnu",
  hngID: "HNG-01204",
  emailAddress: "chinetaadinnu@gmail.com",
  language: "javascript",
};

let outputLine = `Hello World, this is ${output.name} with HNGi7 ID ${output.hngID} and email ${output.emailAddress} using ${output.language} for stage 2 task`;

//console output
console.log(outputLine);
