const credentials = {}

credentials.firstName = "Fongang",
    credentials.lastName = "Rodrique",
    credentials.email = "jarorodriq@gmail.com",
    credentials.HNGi7_ID = "HNG-03522",
    credentials.language = "Javascript"

console.log(`Hello World, this is ${credentials.firstName} ${credentials.lastName} with HNGi7 ID ${credentials.HNGi7_ID} and email ${credentials.email} using ${credentials.language} for stage 2 task`);