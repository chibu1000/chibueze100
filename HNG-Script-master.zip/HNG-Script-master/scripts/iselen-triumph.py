"""This file outputs my name, registration number, email and language used"""

Name= "Iselen Triumph"
boardid = "HNG-04439"
Email= "t4riumph@gmail.com"
language= "python"

print("Hello World, this is " + Name + " with HNGi7 ID " + boardid + " and email " + Email + " using " + language + " for stage 2 task" ) #concatenated string as PHP doesnt recognise f literal


