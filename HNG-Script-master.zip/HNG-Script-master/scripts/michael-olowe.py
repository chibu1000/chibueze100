# Name = Michael olowe
# HNGi7 ID = HNG-02021
# email = michaelolowe321@gmail.com

def function():
    print('Hello world, this is Michael Olowe with HNGi7 ID HNG-02021 and email michaelolowe321@gmail.com using python for stage 2 task')
    
function()