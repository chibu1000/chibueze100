console.log("Hello World, this is Ajibola Ojo with HNGi7 ID HNG-004478 using JavaScript for stage 2 task");
