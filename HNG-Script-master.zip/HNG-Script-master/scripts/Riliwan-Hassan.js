const DETAILS = (fullName, id, language, email) => {return console.log(`Hello World, this is ${fullName} with HNGi7 ID ${id} and email ${email} using ${language} for stage 2 task`);}
DETAILS('Riliwan Hassan', 'HNG-02119', 'JavaScript', 'riliwanhazzan@gmail.com');
