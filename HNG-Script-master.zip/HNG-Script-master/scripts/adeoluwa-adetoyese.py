# Name = Adeoluwa Adetoyese
# ID = HNG-04248
# email = adetoyeseadeoluwa@gmail.com

print("Hello World, this is Adeoluwa Adetoyese with HNGi7 ID HNG-04248 and email adetoyeseadeoluwa@gmail.com using Python for stage 2 task")
