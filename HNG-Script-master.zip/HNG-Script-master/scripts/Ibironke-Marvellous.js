const MarvName = "Ibironke Marvellous";
const MarvId = "HNG-03297";
const MarvLanguage = "JavaScript";
const MarvEmail = "opemipo827@gmail.com"

console.log(
  `Hello World, this is ${MarvName} with HNGi7 ID ${MarvId} and email ${MarvEmail}  using ${MarvLanguage} for stage 2 task`
);

