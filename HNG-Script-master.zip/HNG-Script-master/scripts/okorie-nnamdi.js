const fullName = "Okorie Nnamdi";
const id = "HNG-03880";
const email = "okorie.nnamdy@gmail.com";
const language = "javaScript";

const myOutput = `Hello World, this is ${fullName} with HNGi7 ID ${id} and email ${email} using ${language} for stage 2 task`;

console.log(myOutput);
