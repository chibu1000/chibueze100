//My Javascript solution for HNGi7 Stage 2 task

const myCode = "Hello World, this is Glory Emmanuel with HNGi7 ID HNG-01013 and email emmaglorypraise@gmail.com using Javascript for stage 2 task";

console.log(myCode);
