let hngIntern = {
    fullName : 'Bolarinwa Kazeem',
    id : 'HNG-00305',
    email: 'bola@reliancehmo.com',
    language : 'JavaScript',
    outputString : function(){
        console.log('Hello World, this is ' + this.fullName + ' with HNGi7 ID ' + this.id + ' and email ' + this.email + ' using ' + this.language + ' for stage 2 task'); 
    }
}



hngIntern.outputString();