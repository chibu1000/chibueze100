//File to complete HNG task 2 group work
//By GAMHnile
const GEORGE_DATA = ['George Uweh', 'HNG-01125', 'georgeamhuweh@gmail.com' ,'JavaScript'];


console.log (`Hello World, this is ${GEORGE_DATA[0]} with HNGi7 ID ${GEORGE_DATA[1]} and email ${GEORGE_DATA[2]} using ${GEORGE_DATA[3]} for stage 2 task`);
