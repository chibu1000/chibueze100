const speak = () => {
    let  message = 'Hello World, this is Alexander Domakyaareh with HNGi7 ID HNG-01520 and email zeimedee@gmail.com using JavaScript for stage 2 task';
     return message;
 }
 
 console.log(speak());